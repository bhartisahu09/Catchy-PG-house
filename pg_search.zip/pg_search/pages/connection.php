<?php
 $host ="localhost";
 $user = "root";
 $pass = "";
 
 $con = mysql_connect($host, $user, $pass);
 
 mysql_select_db("pg_db");
 
?>