
<!DOCTYPE html>
<html>
<head>
<title>Facilities Of Catchy PG House</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Catchy Carz Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="css/zoomslider.css" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="css/component.css" />
			<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />

<script type="text/javascript" src="js/modernizr-2.6.2.min.js"></script>
<!--/web-fonts-->
	<link href='//fonts.googleapis.com/css?family=Open+Sans:400,600,600italic,300,300italic,700,400italic' rel='stylesheet' type='text/css'>
	<link href='//fonts.googleapis.com/css?family=Wallpoet' rel='stylesheet' type='text/css'>
	<link href='//fonts.googleapis.com/css?family=Ubuntu:400,500,700,300' rel='stylesheet' type='text/css'>
<!--//web-fonts-->
</head>
<body>
<!--/banner-section-->
		<div id="demo-1" class="banner-inner">
	 <div class="banner-inner-dott">
       <div class="header-top">
		    <!-- /header-left -->
		          <div class="header-left">
				    <!-- /sidebar -->
				         <div id="sidebar"> 
						     <h4 class="menu">Menu</h4>
						          <ul>
							    <li><a href="index.php">Home </a>
							     
							   </li>
							    <li><a href="about_us.php">About Us</a></li>
							   
							    	<li><a href="facilities.php">Facilities</a>
							     
							   </li>
							  
							   <li><a href="search-detail.php">PG Accomodation</a></li>
							    <li><a href="contact.php">Contact Us</a>
							  
							  
						
						   <div id="sidebar-btn">
							   <span></span>
							   <span></span>
							   <span></span>
						   </div>
					   </div>

							 <script>
								  var sidebarbtn = document.getElementById('sidebar-btn');
									var sidebar = document.getElementById('sidebar');
								   sidebarbtn.addEventListener('click', function () {
								  if(sidebar.classList.contains('visible')){
										sidebar.classList.remove('visible'); 
								   }else {
										sidebar.className = 'visible';
									}
								  });
								</script>
					    <!-- //sidebar -->
					  <div class="tag"><a href="#" data-toggle="modal" data-target="#myModal1"> </a></div>
					  <div class="tag"><a href="#" data-toggle="modal" data-target="#myModal2"></a></div>
					</div>
				  <!-- //header-left -->
		             <div class="search-box">
						<div id="sb-search" class="sb-search">
							<form action="#" method="post">
								<input name="search" class="sb-search-input" placeholder="Enter your search term..." type="search" id="search">
								<input class="sb-search-submit" type="submit" value="">
								<span class="sb-icon-search"> </span>
							</form>
						</div>
						<!-- search-scripts -->
						<script src="js/classie.js"></script>
						<script src="js/uisearch.js"></script>
							<script>
								new UISearch( document.getElementById( 'sb-search' ) );
							</script>
						<!-- //search-scripts -->
					    <ul>
							
							<li>
							<a href="#" data-toggle="modal" data-target="#myModal4"><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>Select Your Location</a></li>
			
							<li><button id="showRight" class="navig">Login </button>
							 <div class="cbp-spmenu-push">
							<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right" id="cbp-spmenu-s2">
								<h3>Login</h3>
							<div class="login-inner">
								<div class="login-top">
								 <form action="#" method="post">
									<input type="text" name="email" class="email" placeholder="Email" required=""/>
									<input type="password" name="password" class="password" placeholder="Password" required=""/>	
									<input type="checkbox" id="brand" value="">
									<label for="brand"><span></span> Remember me</label>
								</form>
								<div class="login-bottom">
									<ul>
										<li>
											<a href="#">Forgot password?</a>
										</li>
										<li>
											<form action="#" method="post">
												<input type="submit" value="LOGIN"/>
											</form>
										</li>
									</ul>
									<div class="clearfix"></div>
								</div>
								<div class="clearfix"></div>
													
							</div>
							<div class="social-icons">
							<ul> 
								<li><a href="#"><span class="icons"></span><span class="text">Facebook</span></a></li>
								<li class="twt"><a href="#"><span class="icons"></span><span class="text">Twitter</span></a></li>
								<li class="ggp"><a href="#"><span class="icons"></span><span class="text">Google+</span></a></li>
							</ul> 
						</div>		
							</div> 
							</nav>
						</div> 
					<script src="js/classie2.js"></script>
						<script>
							var menuRight = document.getElementById( 'cbp-spmenu-s2' ),
								showRight = document.getElementById( 'showRight' ),
								body = document.body;
				
							showRight.onclick = function() {
								classie.toggle( this, 'active' );
								classie.toggle( menuRight, 'cbp-spmenu-open' );
								disableOther( 'showRight' );
							};
				
							function disableOther( button ) {
								if( button !== 'showRight' ) {
									classie.toggle( showRight, 'disabled' );
								}
							}
						</script>
						<!--Navigation from Right To Left-->
						    </li>
						</ul>
						
					</div>
				   
						
					</div>
					<div class="clearfix"></div>
		    <!--banner-info-->
			<div class="banner-info">
			   <h1><a href="index.php">Catchy <span class="logo-sub">PG House</span> </a></h1>
			   <h2><span>A HOME AWAY </span> <span>FROM HOME </span></h2>
			     
			</div>
		<!--//banner-info-->	
		</div>
	 </div>
<!-- discounts--
			<div class="modal ab fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog about" role="document">
					<div class="modal-content about">
						<div class="modal-header">
							<button type="button" class="close ab" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>	
								<div class="discount">
									<h3>Get Offers & Discount of</h3>
									<p>Catchy Carz Brand VL in New York</p>
										<form action="#" method="post">
											<select id="country5" onchange="change_country(this.value)" class="frm-field required">
												<option selected="selected" value="-1">-Buying Time Period-</option>
												<option value="0">Just Researching</option>
												<option value="7">1 Week</option>
												<option value="14">2 Weeks</option>
												<option value="30">1 Month</option>
												<option value="60">2 Months</option>
											</select>
											<input type="text" class="Pin code" placeholder="Pin code" required="">
										</form>
								</div>							
						</div>
						 <div class="modal-body about">
								
								<div class="dis-contact">
								  <h4>Contact Information</h4>
												<form action="#" method="post">
													<input type="text" name="name" class="name active" placeholder="Name" required="">
													<input type="text" name="email" class="email" placeholder="Email" required="">
													<input type="text" name="phone" class="phone" placeholder="Phone" required="">
													<div class="d-c">	
														<span class="checkbox1">
															<label class="checkbox"><input type="checkbox" name="" checked=""><i> </i>I agree to Terms and Conditions.</label>
														</span>													

													</div>
													<input type="submit" value="Find Offers">
													
													</form>
								</div>
						 </div>
					</div>
				</div>
			</div>
			<!-- //discounts-->
				<!-- //sign-up--
				<div class="modal ab fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog sign" role="document">
					<div class="modal-content about">
						<div class="modal-header one">
							<button type="button" class="close sg" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>	
								<div class="discount one">
									<h3>Sign Up</h3>
									
								</div>							
						</div>
						 <div class="modal-body about">
								<div class="login-top sign-top one">
							 <form action="#" method="post">
									<input type="text" name="name" class="name active" placeholder="Your Name" required="">
									<input type="text" name="email" class="email" placeholder="Email" required="">
									<input type="password" name="password" class="password" placeholder="Password" required="">		
									<input type="checkbox" id="brand1" value="">
									<label for="brand1"><span></span> Remember me</label>
									<div class="login-bottom one">
									<ul>
										<li>
											<a href="#">Forgot password?</a>
										</li>
										<li>
										
										  <input type="submit" value="SIGN UP">
										
										</li>
									<div class="clearfix"></div>
								</ul>
								</div>	
								</form>
							</div>
							
							
						 </div>
						 <div class="social-icons">
									<ul> 
										<li><a href="#"><span class="icons"></span><span class="text">Facebook</span></a></li>
										<li class="twt"><a href="#"><span class="icons"></span><span class="text">Twitter</span></a></li>
										<li class="ggp"><a href="#"><span class="icons"></span><span class="text">Google+</span></a></li>
									</ul> 
									</div>
								
					</div>
				</div>
			</div>
			<!-- //sign-up-->
				<!-- /location-->
				<div class="modal ab fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog sign" role="document">
					<div class="modal-content about">
						<div class="modal-header one">
							<button type="button" class="close sg" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>	
								<div class="discount one">
									<h3>Please Tell Us Your City</h3>
									
								</div>							
						</div>
						 <div class="modal-body about">
								<div class="login-top sign-top location">
								 <form action="#" method="post">
				                      <select id="country12" onchange="change_country(this.value)" class="frm-field required">
														<option value="null"> Select City</option>
														<option value="city">Mumbai</option>
														<option value="city">Delhi</option>
														<option value="city">Bangalore</option>
														<option value="city">Hyderabad</option>
														<option value="city">Ahmedabad</option>
														<option value="city">Chennai</option>
														<option value="city">Kolkata</option>
														<option value="city">Surat</option>
														<option value="city">Agra</option>
														<option value="city">Pune</option>
														<option value="city">Nagpur</option>
														<option value="city">Visakhapatnam</option>
														<option value="city">Indore</option>
										</select>
								</form>
							     </div>
							
							
						 </div>

								
					</div>
				</div>
			</div>
			<!-- //location-->
			<!-- /get--
				<div class="modal ab fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog sign" role="document">
					<div class="modal-content about">
						<div class="modal-header one">
							<button type="button" class="close sg" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>	
								<div class="discount one">
									<h3>Make car insurance buying easier</h3>
									
								</div>							
						</div>
						 <div class="modal-body about">
								<div class="login-top sign-top get">
								  <ul class="car-insurance">
								       <li><i class="fa fa-signal" aria-hidden="true"></i><h6> Zero <br> Depreciation</h6></li>
									   <li><i class="fa fa-truck" aria-hidden="true"></i><h6> Road-side <br> assistance</h6></li>
									   <li><i class="fa fa-gavel" aria-hidden="true"></i><h6> Hydro-static <br> cover-lock</h6></li>
								     </ul>
							     <form action="#" method="post">
									 
									<input type="text" name="email" class="email" placeholder="Email" required="">
									<input type="password" name="password" class="password" placeholder="Password" required="">		
									<input type="submit" value="Submit">
								</div>	
								</form>
								
							</div>
						
							
						 </div>
								
					</div>
				</div>
			</div>
			<!-- //get-->
		<!--//banner-section-->
				<!--/breadcrumb-->
		    <div class="service-breadcrumb">
				<div class="container">
					<div class="wthree_service_breadcrumb_left">
						<ul>
							<li><a href="index.php">Home</a> <i>|</i></li>
							
							<li>Facilities</li>
						</ul>
					</div>
					
					<div class="clearfix"> </div>
				</div>
			</div>
		<!--//breadcrumb-->
		<!--/sell-car -->
				<div class="sell-car w3l">
					<div class="container">
					   <div class="top-grid-used-cars">
					      <h4 class="tittle">Facilities Of Catchy PG House</h4>
								<div class="car-details">
									 <div class="usd-img"><img src="images/new1.jpg" alt="Used Cars"></div>
									
								</div>
								 <div class="col-md-3 advice-right w3-agile">
					
					
					
					<div class="blo-top1 w3l">
						<div class="tech-btm">
						<h4>The Best PG Rooms IN India </h4>
							<div class="blog-grids">
								<div class="blog-grid-left">
									<a href="single.php"><img src="images/search-detail/pg1.jpg" class="img-responsive" alt=""></a>
								</div>
								<div class="blog-grid-right">
									
									<h5><a href="single.php">Banglore</a> </h5>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="blog-grids">
								<div class="blog-grid-left">
									<a href="single.php"><img src="images/search-detail/pg2.jpg" class="img-responsive" alt=""></a>
								</div>
								<div class="blog-grid-right">
									
									<h5><a href="single.php">Delhi</a> </h5>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="blog-grids">
								<div class="blog-grid-left">
									<a href="single.php"><img src="images/home/pg2.jpg" class="img-responsive" alt=""></a>
								</div>
								<div class="blog-grid-right">
									
									<h5><a href="single.php">Gujrat</a> </h5>
								</div>
								<div class="clearfix"> </div>
							</div>

							
							<div class="blog-grids lost">
								<div class="blog-grid-left">
									<a href="single.php"><img src="images/home/pg3.jpg" class="img-responsive" alt=""></a>
								</div>
								<div class="blog-grid-right">
									
									<h5><a href="single.php">Pune</a> </h5>
								</div>
								<div class="clearfix"> </div>
							</div>
							</div>
						</div>
					</div>
					<div class="clearfix"> </div>
			
		</div>
								<!-- /mid-->
							<div class="middle-grid w3-agile">
									<div class="car-condition">
										<h3>Facilities Provided in PG</h3>
										<ul class="col-md-6 col-sm-6">
											<li><div class="col-md-6 col-sm-6 part"><p>1. Fully Furnished New Executive Rooms</p></div><div class="clearfix"></div></li>
											<li><div class="col-md-6 col-sm-6 part"><p>2. All Rooms are with Good Ventilation</p></div><div class="clearfix"></div></li>
											<li><div class="col-md-6 col-sm-6 part"><p>3. LED TV in Each Room, Sofa in Living Area</p></div><div class="clearfix"></div></li>
											<li><div class="col-md-6 col-sm-6 part"><p>4. Rooms with Attached Bathrooms</p></div><div class="clearfix"></div></li>
											<li><div class="col-md-6 col-sm-6 part"><p>5. High Speed Wi-Fi Internet</p></div><div class="clearfix"></div></li>
											<li><div class="col-md-6 col-sm-6 part"><p>6. North & South Indian Homely Food</p></div><div class="clearfix"></div>
											</li>
										</ul>
										<ul class="col-md-6 col-sm-6">
											<li><div class="col-md-6 col-sm-6 part"><p>7. GYM (Coming Soon), Indoor Games</p></div><div class="clearfix"></div></li>
											<li><div class="col-md-6 col-sm-6 part"><p>8. Fully Automatic Washing Machine</p></div><div class="clearfix"></div></li>
											<li><div class="col-md-6 col-sm-6 part"><p>9. Daily 3 Times Tasty Food</p></div><div class="clearfix"></div></li>
											
											<li><div class="col-md-6 col-sm-6 part"><p>10. Fridge for Common Use</p></div><div class="clearfix"></div></li>
											<li><div class="col-md-6 col-sm-6 part"><p>11. RO Purified Drinking Water</p></div><div class="clearfix"></div></li>
											<li><div class="col-md-6 col-sm-6 part"><p>12. 24 Hours Hot & Cold Water</p></div><div class="clearfix"></div></li>
											<li><div class="col-md-6 col-sm-6 part"><p>13. Individual Wardrobes with Lockers</p></div><div class="clearfix"></div></li>
											
											 <!-- <li><div class="col-md-6 col-sm-6 part"><p>14. 1,  2, 3, 4 Sharing Rooms</p></div><div class="clearfix"></div></li> --> 
										</ul>
										<div class="clearfix"></div>
										
									</div>
								</div>
					<!-- //mid-->
					<!-- /bottom--
					<div class="owners-comments w3l car-condition">
						<h3>Why Choose Us</h3>
						<div>
							<input type="checkbox" class="read-more-state" id="post-2" />
								<ul class="read-more-wrap">
									<li>Catchy PG House envisions effortless and inexpensive means of finding suitable property on rent using emerging internet and global positioning systems. We aim to push together Keraidaar.com to global level and become a multi-billion company with high value. Core values of the organization on which we stands and sustain, include customer satisfactions, minimizing the brokerage and involvement of time consuming on-road hunt for dwelling places. We shall work constantly for improving the time bound delivery of the services and quality assurance of the data on our website. Furthermore, involvement of best information technology resources and up gradation with the advent of internet and online tools, as well as transparent and user friendly access to the portal shall guide us for innovations and therefore we shall constantly work for improving our services. We shall always keep a friendly and transparent workplace environment providing unlimited space for simultaneous growth of employees and organization.</li>
									
								</ul>
							
						</div>
					</div>
				<!-- //bottom-->
				
				
		</div>
	</div>
		<!-- //sell-car -->
	<!-- footer -->
	<div class="footer">
		<div class="container">
			<div class="footer-grids">
				<div class="col-md-4 footer-grid animated wow slideInLeft" data-wow-delay=".5s">
					<h3>About Us</h3>
					<p>Our Priority is Security, Comfort & Homely Atomsphere.<span>Parents Need not worry as we have PG's from All Over India
						Every room has  Fully Furnished modern With Attach Bathrooms, All Individuals Non Sharing With Beds closet Study table, 24 hours RO water is available for drinking.</span></p>
				</div>
				<div class="col-md-4 footer-grid animated wow slideInLeft" data-wow-delay=".6s">
					<h3>Contact Info</h3>
					<ul>
						<li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>1234k Avenue, 4th block, <span>Raipur City.</span></li>
						<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">info@example.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+1234 567 567</li>
					</ul>
				</div>
				<div class="col-md-4 footer-grid animated wow slideInLeft" data-wow-delay=".7s">
					<h3>PG Houses</h3>
					<div class="footer-grid-left">
						<a href="single.php"><img src="images/home/pg3.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="single.php"><img src="images/home/pg4.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="single.php"><img src="images/home/pg5.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="single.php"><img src="images/home/pg7.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="single.php"><img src="images/home/pg11.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="single.php"><img src="images/home/pg8.jpg" alt=" " class="img-responsive" /></a>
					</div>
					
					<div class="clearfix"> </div>
				</div>
				
				<div class="clearfix"> </div>
			</div>
			<div class="footer-logo animated wow slideInUp" data-wow-delay=".5s">
				<h2><a href="index.php">Catchy PG House </a></h2>
			</div>
			<div class="copy-right animated wow slideInUp" data-wow-delay=".5s">
				<p>Copyright 2018 © All Rights Reserved By CATCHY PAYING GUEST</a></p>
			</div>
		</div>
	</div>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>

 

</body>
</html>