

 <div class="col-md-4 advice-right w3-agile">
					<div class="blo-top">
						<div class="tech-btm one">
						<img src="images/pg/default.jpg" class="img-responsive" alt="">
						</div>
					</div>
					
				
					<div class="blo-top1 w3l">
						<div class="tech-btm">
						<h4> PG According to Your Need</h4>
							<div class="blog-grids">
								<div class="blog-grid-left">
									<img src="images/home/pg4.jpg" class="img-responsive" alt="">
								</div>
								<div class="blog-grid-right">
									
									<h5>1 BHK PG HOUSE  </h5>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="blog-grids">
								<div class="blog-grid-left">
									<img src="images/home/pg3.jpg" class="img-responsive" alt="">
								</div>
								<div class="blog-grid-right">
									
									<h5>2 BHK PG HOUSE </h5>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="blog-grids">
								<div class="blog-grid-left">
									<img src="images/home/pg2.jpg" class="img-responsive" alt="">
								</div>
								<div class="blog-grid-right">
									
									<h5>3BHK PG HOUSE </h5>
								</div>
								<div class="clearfix"> </div>
							</div>
							
						</div>
					</div>
					<div class="clearfix"> </div>

					<div class="popular-videos">
				    <h3>Popular Videos</h3>
					
				  <iframe  src="https://www.youtube.com/embed/kqhrmoGPZFI" ></iframe>
				</div>
			</div>
		</div>
