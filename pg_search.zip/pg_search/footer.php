<div class="footer">
		<div class="container">
			<div class="footer-grids">
				<div class="col-md-4 footer-grid animated wow slideInLeft" data-wow-delay=".5s">
					<h3>About Us</h3>
					<p>Our Priority is Security, Comfort & Homely Atomsphere.<span>Parents Need not worry as we have PG's from All Over India
						Every room has  Fully Furnished modern With Attach Bathrooms, All Individuals Non Sharing With Beds closet Study table, 24 hours RO water is available for drinking.</span></p>
				</div>
				<div class="col-md-4 footer-grid animated wow slideInLeft" data-wow-delay=".6s">
					<h3>Contact Info</h3>
					<ul>
						<li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>1234k Avenue, 4th block, <span>Raipur City.</span></li>
						<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">info@example.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+1234 567 567</li>
					</ul>
				</div>
				<div class="col-md-4 footer-grid animated wow slideInLeft" data-wow-delay=".7s">
					<h3>PG Houses</h3>
					<div class="footer-grid-left">
						<img src="images/home/pg3.jpg" alt=" " class="img-responsive" />
					</div>
					<div class="footer-grid-left">
						<img src="images/home/pg4.jpg" alt=" " class="img-responsive" />
					</div>
					<div class="footer-grid-left">
						<img src="images/home/pg5.jpg" alt=" " class="img-responsive" />
					</div>
					<div class="footer-grid-left">
						<img src="images/home/pg7.jpg" alt=" " class="img-responsive" />
					</div>
					<div class="footer-grid-left">
						<img src="images/home/pg11.jpg" alt=" " class="img-responsive" />
					</div>
					<div class="footer-grid-left">
						<img src="images/home/pg8.jpg" alt=" " class="img-responsive" />
					</div>
					
					<div class="clearfix"> </div>
				</div>
				
				<div class="clearfix"> </div>
			</div>
			<div class="footer-logo animated wow slideInUp" data-wow-delay=".5s">
				<h2><a href="index.php">Catchy PG House </a></h2>
			</div>
			<div class="copy-right animated wow slideInUp" data-wow-delay=".5s">
				<p>Copyright 2018 © All Rights Reserved By CATCHY PAYING GUEST</p>
			</div>
		</div>
	</div>

<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/jquery.light-carousel.js"></script> 
				<script>
					$('.sample1').lightCarousel();
				</script> 
				<link href="css/light-carousel.css" rel="stylesheet" type="text/css">

<script type="text/javascript" src="js/jquery.zoomslider.min.js"></script>
		<script type="text/javascript">
				 $(window).load(function() {			
				  $("#flexiselDemo").flexisel({
					visibleItems:1,
					animationSpeed: 1000,
					autoPlay: true,
					autoPlaySpeed:1000,    		
					pauseOnHover:true,
					enableResponsiveBreakpoints: true,
					responsiveBreakpoints: { 
						portrait: { 
							changePoint:480,
							visibleItems: 1
						}, 
						landscape: { 
							changePoint:640,
							visibleItems: 1
						},
						tablet: { 
							changePoint:768,
							visibleItems: 1
						}
					}
				});
				});
				</script>
						<script type="text/javascript">
				 $(window).load(function() {			
				  $("#flexiselDemo1").flexisel({
					visibleItems: 4,
					animationSpeed: 1000,
					autoPlay: true,
					autoPlaySpeed: 3000,    		
					pauseOnHover:true,
					enableResponsiveBreakpoints: true,
					responsiveBreakpoints: { 
						portrait: { 
							changePoint:480,
							visibleItems: 1
						}, 
						landscape: { 
							changePoint:640,
							visibleItems: 2
						},
						tablet: { 
							changePoint:768,
							visibleItems: 3
						}
					}
				});
				});
				</script>
					<script type="text/javascript" src="js/jquery.flexisel.js"></script>
                    <script src="js/bootstrap.js"></script>
 

</body>
</html>