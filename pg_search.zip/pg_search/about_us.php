<?php include('top_header.php') ?>
<body>
<!--/banner-section-->
		<div id="demo-1" class="banner-inner">
	 <div class="banner-inner-dott">
       <div class="header-top">
		    <!-- /header-left -->
		      	<?php include('header.php') ?>
		    <!--banner-info-->
			<div class="banner-info">
			   <h1><a href="index.php">Catchy <span class="logo-sub">PG House</span> </a></h1>
			   <h2><span>A HOME AWAY </span> <span>FROM HOME </span></h2>
			     
			</div>
		<!--//banner-info-->	
		</div>
	 </div>

			<!-- //sign-up-->
				<!-- /location-->
				<div class="modal ab fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog sign" role="document">
					<div class="modal-content about">
						<div class="modal-header one">
							<button type="button" class="close sg" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>	
								<div class="discount one">
									<h3>Please Tell Us Your City</h3>
									
								</div>							
						</div>
						 <div class="modal-body about">
								<div class="login-top sign-top location">
								 <form action="#" method="post">
				                      <select id="country12" onchange="change_country(this.value)" class="frm-field required">
														<option value="null"> Select City</option>
														<option value="city">Mumbai</option>
														<option value="city">Delhi</option>
														<option value="city">Bangalore</option>
														<option value="city">Hyderabad</option>
														<option value="city">Ahmedabad</option>
														<option value="city">Chennai</option>
														<option value="city">Kolkata</option>
														<option value="city">Surat</option>
														<option value="city">Agra</option>
														<option value="city">Pune</option>
														<option value="city">Nagpur</option>
														<option value="city">Visakhapatnam</option>
														<option value="city">Indore</option>
										</select>
								</form>
							     </div>
							
							
						 </div>

								
					</div>
				</div>
			</div>
			<!-- //location-->
			
		<!--//banner-section-->
				<!--/breadcrumb-->
		    <div class="service-breadcrumb">
				<div class="container">
					<div class="wthree_service_breadcrumb_left">
						<ul>
							<li><a href="index.php">Home</a> <i>|</i></li>
							
							<li>About Us</li>
						</ul>
					</div>
					
					<div class="clearfix"> </div>
				</div>
			</div>
		<!--//breadcrumb-->
		<!--/sell-car -->
				<div class="sell-car w3l">
					<div class="container">
					   
								
					<!-- /bottom-->
					<div class="owners-comments w3l car-condition">
						<h3>Why Choose Us</h3>
						<div>
							<input type="checkbox" class="read-more-state" id="post-2" />
								<ul class="read-more-wrap">
									<li>Catchy PG House envisions effortless and inexpensive means of finding suitable property on rent using emerging internet and global positioning systems. We aim to push together Keraidaar.com to global level and become a multi-billion company with high value. Core values of the organization on which we stands and sustain, include customer satisfactions, minimizing the brokerage and involvement of time consuming on-road hunt for dwelling places. We shall work constantly for improving the time bound delivery of the services and quality assurance of the data on our website. Furthermore, involvement of best information technology resources and up gradation with the advent of internet and online tools, as well as transparent and user friendly access to the portal shall guide us for innovations and therefore we shall constantly work for improving our services. We shall always keep a friendly and transparent workplace environment providing unlimited space for simultaneous growth of employees and organization.</li>
									
								</ul>
							
						</div>
					</div>
				<!-- //bottom-->
				
				
		</div>
	</div>
		<!-- //sell-car -->
	<!-- footer -->
		<?php include('footer.php') ?>